import flet as ft


def content_shadow(widget_class):
    def wrapper(*args, **kwargs):
        instance = widget_class(*args, **kwargs)
        if instance.content:
            instance.content.shadow = ft.BoxShadow(spread_radius=3, blur_radius=15)
        return instance
    return wrapper


def content_blur(x: float=20.0, y: float=20.0):
    def decorator(widget_class):
        def wrapper(*args, **kwargs):
            instance = widget_class(*args, **kwargs)
            if instance.content:
                instance.content.blur = ft.Blur(x, y)
            return instance
        return wrapper
    return decorator


def content_color(color_name: str='ft.colors.BLUE'):
    def decorator(widget_class):
        def wrapper(*args, **kwargs):
            instance = widget_class(*args, **kwargs)
            if instance.content:
                instance.content.bgcolor = color_name
            return instance
        return wrapper
    return decorator
